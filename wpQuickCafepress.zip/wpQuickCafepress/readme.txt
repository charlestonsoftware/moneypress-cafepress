== CSL Quick Cafpress ==
Contributors: Cyber Sprocket Labs
Donate link: http://www.cybersprocket.com/proucts/wpquickcafepress/
Tags: plugin,post,page,cafepress,affiliate,shirts,pod,print-on-demand,store
Requires at least: 2.6
Test up to: 2.9.2
Stable tag: 1.0

Display your CafePress store products on pages and posts using shortcodes.

== Description ==

This plugin creates a Cafepress product listing within your posts or pages.  Requires PHP5 with XMLDOM.

Features:
* Uses your own API key.
* No revenue sharing, you keep 100% of your sales.

== Installation ==

* Get the ZIP file from Cyber Sprocket
* Get your API key from the Cafepress developer site.
* Install the plugin using the zip file.
* Go to wpCafepress in the Wordpress Settings menu.
* Enter your Cafepress API key.


Update History

V1.1 (March 15th, 2010)
- Initial release (only released on cybersprocket.com)
